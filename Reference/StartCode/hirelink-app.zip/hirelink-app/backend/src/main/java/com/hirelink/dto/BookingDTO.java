package com.hirelink.dto;

import com.hirelink.entity.Booking;
import jakarta.validation.constraints.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BookingDTO {
    private Long bookingId;
    private String bookingNumber;
    private Long userId;
    private String userName;
    private String userPhone;
    private Long providerId;
    private String providerName;
    private String providerPhone;
    private String businessName;
    private Long serviceId;
    private String serviceName;
    private String categoryName;
    private LocalDate scheduledDate;
    private LocalTime scheduledTime;
    private String serviceAddress;
    private String servicePincode;
    private BigDecimal serviceLatitude;
    private BigDecimal serviceLongitude;
    private String issueTitle;
    private String issueDescription;
    private String issueImages;
    private Booking.UrgencyLevel urgencyLevel;
    private BigDecimal estimatedAmount;
    private BigDecimal materialCost;
    private BigDecimal laborCost;
    private BigDecimal travelCost;
    private BigDecimal discountAmount;
    private BigDecimal taxAmount;
    private BigDecimal finalAmount;
    private Booking.BookingStatus bookingStatus;
    private Booking.CancelledBy cancelledBy;
    private String cancellationReason;
    private String workSummary;
    private BigDecimal userRating;
    private LocalDateTime createdAt;

    public static BookingDTO fromEntity(Booking booking) {
        return BookingDTO.builder()
                .bookingId(booking.getBookingId())
                .bookingNumber(booking.getBookingNumber())
                .userId(booking.getUser().getUserId())
                .userName(booking.getUser().getName())
                .userPhone(booking.getUser().getPhone())
                .providerId(booking.getProvider().getProviderId())
                .providerName(booking.getProvider().getUser().getName())
                .providerPhone(booking.getProvider().getUser().getPhone())
                .businessName(booking.getProvider().getBusinessName())
                .serviceId(booking.getService().getServiceId())
                .serviceName(booking.getService().getServiceName())
                .categoryName(booking.getService().getCategory().getCategoryName())
                .scheduledDate(booking.getScheduledDate())
                .scheduledTime(booking.getScheduledTime())
                .serviceAddress(booking.getServiceAddress())
                .servicePincode(booking.getServicePincode())
                .serviceLatitude(booking.getServiceLatitude())
                .serviceLongitude(booking.getServiceLongitude())
                .issueTitle(booking.getIssueTitle())
                .issueDescription(booking.getIssueDescription())
                .issueImages(booking.getIssueImages())
                .urgencyLevel(booking.getUrgencyLevel())
                .estimatedAmount(booking.getEstimatedAmount())
                .materialCost(booking.getMaterialCost())
                .laborCost(booking.getLaborCost())
                .travelCost(booking.getTravelCost())
                .discountAmount(booking.getDiscountAmount())
                .taxAmount(booking.getTaxAmount())
                .finalAmount(booking.getFinalAmount())
                .bookingStatus(booking.getBookingStatus())
                .cancelledBy(booking.getCancelledBy())
                .cancellationReason(booking.getCancellationReason())
                .workSummary(booking.getWorkSummary())
                .userRating(booking.getUserRating())
                .createdAt(booking.getCreatedAt())
                .build();
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CreateBookingRequest {
        @NotNull(message = "Service ID is required")
        private Long serviceId;

        @NotNull(message = "Scheduled date is required")
        @Future(message = "Scheduled date must be in the future")
        private LocalDate scheduledDate;

        @NotNull(message = "Scheduled time is required")
        private LocalTime scheduledTime;

        @NotBlank(message = "Service address is required")
        private String serviceAddress;

        @NotBlank(message = "Pincode is required")
        @Pattern(regexp = "^[0-9]{6}$", message = "Invalid pincode")
        private String servicePincode;

        private BigDecimal serviceLatitude;
        private BigDecimal serviceLongitude;
        private String issueTitle;
        private String issueDescription;
        private String issueImages;
        private Booking.UrgencyLevel urgencyLevel;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class UpdateBookingStatusRequest {
        @NotNull(message = "Status is required")
        private Booking.BookingStatus status;
        private String reason;
        private BigDecimal finalAmount;
        private String workSummary;
    }
}
