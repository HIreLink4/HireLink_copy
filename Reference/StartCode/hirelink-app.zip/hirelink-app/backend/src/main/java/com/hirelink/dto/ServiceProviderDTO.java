package com.hirelink.dto;

import com.hirelink.entity.ServiceProvider;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ServiceProviderDTO {
    private Long providerId;
    private Long userId;
    private String name;
    private String phone;
    private String email;
    private String profileImageUrl;
    private String businessName;
    private String businessDescription;
    private String tagline;
    private Integer experienceYears;
    private String specializations;
    private String certifications;
    private BigDecimal baseLatitude;
    private BigDecimal baseLongitude;
    private String basePincode;
    private Integer serviceRadiusKm;
    private ServiceProvider.KycStatus kycStatus;
    private BigDecimal averageRating;
    private Integer totalRatings;
    private Integer totalBookings;
    private Integer completedBookings;
    private BigDecimal completionRate;
    private Boolean isAvailable;
    private ServiceProvider.AvailabilityStatus availabilityStatus;
    private Boolean isFeatured;
    private LocalDateTime createdAt;

    public static ServiceProviderDTO fromEntity(ServiceProvider provider) {
        return ServiceProviderDTO.builder()
                .providerId(provider.getProviderId())
                .userId(provider.getUser().getUserId())
                .name(provider.getUser().getName())
                .phone(provider.getUser().getPhone())
                .email(provider.getUser().getEmail())
                .profileImageUrl(provider.getUser().getProfileImageUrl())
                .businessName(provider.getBusinessName())
                .businessDescription(provider.getBusinessDescription())
                .tagline(provider.getTagline())
                .experienceYears(provider.getExperienceYears())
                .specializations(provider.getSpecializations())
                .certifications(provider.getCertifications())
                .baseLatitude(provider.getBaseLatitude())
                .baseLongitude(provider.getBaseLongitude())
                .basePincode(provider.getBasePincode())
                .serviceRadiusKm(provider.getServiceRadiusKm())
                .kycStatus(provider.getKycStatus())
                .averageRating(provider.getAverageRating())
                .totalRatings(provider.getTotalRatings())
                .totalBookings(provider.getTotalBookings())
                .completedBookings(provider.getCompletedBookings())
                .completionRate(provider.getCompletionRate())
                .isAvailable(provider.getIsAvailable())
                .availabilityStatus(provider.getAvailabilityStatus())
                .isFeatured(provider.getIsFeatured())
                .createdAt(provider.getCreatedAt())
                .build();
    }
}
