package com.hirelink.dto;

import com.hirelink.entity.Service;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ServiceDTO {
    private Long serviceId;
    private Long providerId;
    private String providerName;
    private String providerBusinessName;
    private Long categoryId;
    private String categoryName;
    private String serviceName;
    private String serviceDescription;
    private String serviceHighlights;
    private BigDecimal basePrice;
    private Service.PriceType priceType;
    private BigDecimal minPrice;
    private BigDecimal maxPrice;
    private Integer estimatedDurationMinutes;
    private Integer advanceBookingHours;
    private Boolean materialsIncluded;
    private Boolean isActive;
    private Integer timesBooked;
    private BigDecimal averageRating;
    private Integer totalReviews;
    private LocalDateTime createdAt;

    public static ServiceDTO fromEntity(Service service) {
        return ServiceDTO.builder()
                .serviceId(service.getServiceId())
                .providerId(service.getProvider().getProviderId())
                .providerName(service.getProvider().getUser().getName())
                .providerBusinessName(service.getProvider().getBusinessName())
                .categoryId(service.getCategory().getCategoryId())
                .categoryName(service.getCategory().getCategoryName())
                .serviceName(service.getServiceName())
                .serviceDescription(service.getServiceDescription())
                .serviceHighlights(service.getServiceHighlights())
                .basePrice(service.getBasePrice())
                .priceType(service.getPriceType())
                .minPrice(service.getMinPrice())
                .maxPrice(service.getMaxPrice())
                .estimatedDurationMinutes(service.getEstimatedDurationMinutes())
                .advanceBookingHours(service.getAdvanceBookingHours())
                .materialsIncluded(service.getMaterialsIncluded())
                .isActive(service.getIsActive())
                .timesBooked(service.getTimesBooked())
                .averageRating(service.getAverageRating())
                .totalReviews(service.getTotalReviews())
                .createdAt(service.getCreatedAt())
                .build();
    }
}
