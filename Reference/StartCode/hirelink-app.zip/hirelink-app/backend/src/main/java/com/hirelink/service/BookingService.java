package com.hirelink.service;

import com.hirelink.dto.BookingDTO;
import com.hirelink.entity.Booking;
import com.hirelink.entity.Service;
import com.hirelink.entity.ServiceProvider;
import com.hirelink.entity.User;
import com.hirelink.exception.BadRequestException;
import com.hirelink.exception.ResourceNotFoundException;
import com.hirelink.repository.BookingRepository;
import com.hirelink.repository.ServiceRepository;
import com.hirelink.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

@org.springframework.stereotype.Service
@RequiredArgsConstructor
public class BookingService {

    private final BookingRepository bookingRepository;
    private final ServiceRepository serviceRepository;
    private final UserRepository userRepository;

    @Transactional
    public BookingDTO createBooking(Long userId, BookingDTO.CreateBookingRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Service service = serviceRepository.findById(request.getServiceId())
                .orElseThrow(() -> new ResourceNotFoundException("Service not found"));

        ServiceProvider provider = service.getProvider();

        // Validate booking date/time
        if (request.getScheduledDate().isBefore(LocalDate.now())) {
            throw new BadRequestException("Scheduled date cannot be in the past");
        }

        // Generate booking number
        String bookingNumber = generateBookingNumber();

        Booking booking = Booking.builder()
                .bookingNumber(bookingNumber)
                .user(user)
                .provider(provider)
                .service(service)
                .scheduledDate(request.getScheduledDate())
                .scheduledTime(request.getScheduledTime())
                .serviceAddress(request.getServiceAddress())
                .servicePincode(request.getServicePincode())
                .serviceLatitude(request.getServiceLatitude())
                .serviceLongitude(request.getServiceLongitude())
                .issueTitle(request.getIssueTitle())
                .issueDescription(request.getIssueDescription())
                .issueImages(request.getIssueImages())
                .urgencyLevel(request.getUrgencyLevel() != null ? request.getUrgencyLevel() : Booking.UrgencyLevel.MEDIUM)
                .estimatedAmount(service.getBasePrice())
                .bookingStatus(Booking.BookingStatus.PENDING)
                .build();

        booking = bookingRepository.save(booking);
        return BookingDTO.fromEntity(booking);
    }

    public Page<BookingDTO> getUserBookings(Long userId, Pageable pageable) {
        return bookingRepository.findByUser_UserId(userId, pageable)
                .map(BookingDTO::fromEntity);
    }

    public Page<BookingDTO> getProviderBookings(Long providerId, Pageable pageable) {
        return bookingRepository.findByProvider_ProviderId(providerId, pageable)
                .map(BookingDTO::fromEntity);
    }

    public BookingDTO getBookingById(Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));
        return BookingDTO.fromEntity(booking);
    }

    public BookingDTO getBookingByNumber(String bookingNumber) {
        Booking booking = bookingRepository.findByBookingNumber(bookingNumber)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));
        return BookingDTO.fromEntity(booking);
    }

    @Transactional
    public BookingDTO updateBookingStatus(Long bookingId, BookingDTO.UpdateBookingStatusRequest request) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));

        booking.setBookingStatus(request.getStatus());

        if (request.getStatus() == Booking.BookingStatus.CANCELLED) {
            booking.setCancelledAt(LocalDateTime.now());
            booking.setCancellationReason(request.getReason());
        }

        if (request.getStatus() == Booking.BookingStatus.IN_PROGRESS) {
            booking.setWorkStartedAt(LocalDateTime.now());
        }

        if (request.getStatus() == Booking.BookingStatus.COMPLETED) {
            booking.setWorkCompletedAt(LocalDateTime.now());
            booking.setWorkSummary(request.getWorkSummary());
            if (request.getFinalAmount() != null) {
                booking.setFinalAmount(request.getFinalAmount());
            }
        }

        booking = bookingRepository.save(booking);
        return BookingDTO.fromEntity(booking);
    }

    public List<BookingDTO> getUpcomingBookings(LocalDate date) {
        return bookingRepository.findUpcomingBookingsForDate(date)
                .stream()
                .map(BookingDTO::fromEntity)
                .collect(Collectors.toList());
    }

    private String generateBookingNumber() {
        String datePart = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        String randomPart = String.format("%05d", new Random().nextInt(100000));
        return "HL" + datePart + randomPart;
    }
}
