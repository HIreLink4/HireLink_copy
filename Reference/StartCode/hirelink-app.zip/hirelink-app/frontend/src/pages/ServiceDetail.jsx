import { useState } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom'
import { StarIcon, ClockIcon, CheckCircleIcon, ShieldCheckIcon } from '@heroicons/react/24/solid'
import { CalendarIcon, MapPinIcon } from '@heroicons/react/24/outline'
import { useAuthStore } from '../context/authStore'
import toast from 'react-hot-toast'

// Mock service data
const serviceData = {
  id: 1,
  name: 'Fan Installation',
  category: 'Electrical',
  categorySlug: 'electrical',
  price: 299,
  priceType: 'FIXED',
  rating: 4.8,
  reviews: 234,
  duration: '30-45 mins',
  description: 'Professional ceiling fan installation service. Our experts will safely install your new ceiling fan with proper wiring and balancing.',
  highlights: [
    'Professional installation by certified electricians',
    'Proper wiring and connection check',
    'Fan balancing for smooth operation',
    'Safety inspection included',
    '30-day service warranty'
  ],
  provider: {
    id: 1,
    name: 'Ramesh Kumar',
    businessName: 'Ramesh Electrical Services',
    rating: 4.75,
    totalBookings: 1250,
    experienceYears: 15,
    isVerified: true
  },
  reviewsList: [
    { id: 1, user: 'Arun K.', rating: 5, comment: 'Excellent service! Very professional and on time.', date: '2 days ago' },
    { id: 2, user: 'Priya S.', rating: 4, comment: 'Good work, fan is running smoothly.', date: '1 week ago' },
    { id: 3, user: 'Vijay M.', rating: 5, comment: 'Best electrician in the area. Highly recommend!', date: '2 weeks ago' },
  ]
}

export default function ServiceDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { isAuthenticated } = useAuthStore()
  const [selectedDate, setSelectedDate] = useState('')
  const [selectedTime, setSelectedTime] = useState('')
  const [address, setAddress] = useState('')
  const [pincode, setPincode] = useState('')
  const [issueDescription, setIssueDescription] = useState('')

  const service = serviceData // In real app, fetch by id

  const timeSlots = [
    '09:00 AM', '10:00 AM', '11:00 AM', '12:00 PM',
    '02:00 PM', '03:00 PM', '04:00 PM', '05:00 PM'
  ]

  const handleBooking = (e) => {
    e.preventDefault()
    
    if (!isAuthenticated) {
      toast.error('Please login to book a service')
      navigate('/login')
      return
    }

    if (!selectedDate || !selectedTime || !address || !pincode) {
      toast.error('Please fill all required fields')
      return
    }

    // In real app, call API to create booking
    toast.success('Booking request sent!')
    navigate('/bookings')
  }

  // Get min date (tomorrow)
  const tomorrow = new Date()
  tomorrow.setDate(tomorrow.getDate() + 1)
  const minDate = tomorrow.toISOString().split('T')[0]

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Breadcrumb */}
      <nav className="text-sm mb-6">
        <ol className="flex items-center space-x-2 text-gray-500">
          <li><Link to="/" className="hover:text-primary-600">Home</Link></li>
          <li>/</li>
          <li><Link to={`/categories/${service.categorySlug}`} className="hover:text-primary-600">{service.category}</Link></li>
          <li>/</li>
          <li className="text-gray-900 font-medium">{service.name}</li>
        </ol>
      </nav>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Service Details */}
        <div className="lg:col-span-2 space-y-6">
          {/* Main Info */}
          <div className="card p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <span className="text-sm text-primary-600 font-medium">{service.category}</span>
                <h1 className="text-2xl font-bold text-gray-900 mt-1">{service.name}</h1>
              </div>
              <div className="flex items-center bg-green-50 px-3 py-1 rounded-lg">
                <StarIcon className="h-5 w-5 text-green-600" />
                <span className="font-semibold text-green-700 ml-1">{service.rating}</span>
                <span className="text-green-600 text-sm ml-1">({service.reviews})</span>
              </div>
            </div>
            
            <p className="text-gray-600 mb-4">{service.description}</p>
            
            <div className="flex items-center space-x-6 text-sm text-gray-500">
              <span className="flex items-center">
                <ClockIcon className="h-5 w-5 mr-1" />
                {service.duration}
              </span>
              <span className="flex items-center">
                <CheckCircleIcon className="h-5 w-5 mr-1 text-green-500" />
                Warranty Included
              </span>
            </div>
          </div>

          {/* Highlights */}
          <div className="card p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">What's Included</h2>
            <ul className="space-y-3">
              {service.highlights.map((highlight, idx) => (
                <li key={idx} className="flex items-start">
                  <CheckCircleIcon className="h-5 w-5 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-600">{highlight}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Provider Info */}
          <div className="card p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Service Provider</h2>
            <Link to={`/providers/${service.provider.id}`} className="flex items-center justify-between hover:bg-gray-50 -m-2 p-2 rounded-lg">
              <div className="flex items-center space-x-4">
                <div className="w-14 h-14 bg-primary-100 rounded-full flex items-center justify-center">
                  <span className="text-primary-700 font-bold text-xl">
                    {service.provider.name.charAt(0)}
                  </span>
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <h3 className="font-semibold text-gray-900">{service.provider.businessName}</h3>
                    {service.provider.isVerified && (
                      <ShieldCheckIcon className="h-5 w-5 text-blue-500" />
                    )}
                  </div>
                  <p className="text-gray-500 text-sm">
                    {service.provider.experienceYears} years exp • {service.provider.totalBookings}+ bookings
                  </p>
                </div>
              </div>
              <div className="text-right">
                <div className="flex items-center">
                  <StarIcon className="h-4 w-4 text-yellow-400" />
                  <span className="font-medium ml-1">{service.provider.rating}</span>
                </div>
              </div>
            </Link>
          </div>

          {/* Reviews */}
          <div className="card p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Customer Reviews</h2>
            <div className="space-y-4">
              {service.reviewsList.map((review) => (
                <div key={review.id} className="border-b last:border-0 pb-4 last:pb-0">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <span className="font-medium text-gray-900">{review.user}</span>
                      <div className="flex items-center bg-green-50 px-2 py-0.5 rounded">
                        <StarIcon className="h-3 w-3 text-green-600" />
                        <span className="text-sm text-green-700 ml-1">{review.rating}</span>
                      </div>
                    </div>
                    <span className="text-sm text-gray-500">{review.date}</span>
                  </div>
                  <p className="text-gray-600 text-sm">{review.comment}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Booking Card */}
        <div className="lg:col-span-1">
          <div className="card p-6 sticky top-24">
            <div className="mb-6">
              <span className="text-3xl font-bold text-gray-900">₹{service.price}</span>
              <span className="text-gray-500 ml-1">onwards</span>
            </div>

            <form onSubmit={handleBooking} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <CalendarIcon className="h-4 w-4 inline mr-1" />
                  Select Date *
                </label>
                <input
                  type="date"
                  min={minDate}
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="input"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Select Time *
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {timeSlots.map((time) => (
                    <button
                      key={time}
                      type="button"
                      onClick={() => setSelectedTime(time)}
                      className={`py-2 px-3 text-sm rounded-lg border transition-colors ${
                        selectedTime === time
                          ? 'border-primary-600 bg-primary-50 text-primary-700'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      {time}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <MapPinIcon className="h-4 w-4 inline mr-1" />
                  Service Address *
                </label>
                <textarea
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="input"
                  rows={2}
                  placeholder="Enter complete address"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Pincode *
                </label>
                <input
                  type="text"
                  value={pincode}
                  onChange={(e) => setPincode(e.target.value)}
                  className="input"
                  placeholder="6-digit pincode"
                  pattern="[0-9]{6}"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Issue Description (Optional)
                </label>
                <textarea
                  value={issueDescription}
                  onChange={(e) => setIssueDescription(e.target.value)}
                  className="input"
                  rows={2}
                  placeholder="Describe your issue briefly..."
                />
              </div>

              <button type="submit" className="w-full btn-primary py-3">
                Book Now
              </button>

              <p className="text-xs text-gray-500 text-center">
                Free cancellation up to 4 hours before scheduled time
              </p>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}
