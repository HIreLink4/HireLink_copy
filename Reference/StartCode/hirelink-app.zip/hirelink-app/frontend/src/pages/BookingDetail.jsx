import { useParams, Link, useNavigate } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from 'react-query'
import { bookingsAPI } from '../services/api'
import { format } from 'date-fns'
import toast from 'react-hot-toast'
import { 
  CalendarIcon, 
  ClockIcon, 
  MapPinIcon,
  PhoneIcon,
  UserIcon,
  CurrencyRupeeIcon,
  CheckCircleIcon,
  XCircleIcon,
  ArrowLeftIcon
} from '@heroicons/react/24/outline'

const statusColors = {
  PENDING: 'bg-yellow-100 text-yellow-800 border-yellow-200',
  ACCEPTED: 'bg-blue-100 text-blue-800 border-blue-200',
  CONFIRMED: 'bg-blue-100 text-blue-800 border-blue-200',
  IN_PROGRESS: 'bg-purple-100 text-purple-800 border-purple-200',
  COMPLETED: 'bg-green-100 text-green-800 border-green-200',
  CANCELLED: 'bg-red-100 text-red-800 border-red-200',
  DISPUTED: 'bg-orange-100 text-orange-800 border-orange-200',
  REFUNDED: 'bg-gray-100 text-gray-800 border-gray-200',
}

const statusSteps = ['PENDING', 'ACCEPTED', 'IN_PROGRESS', 'COMPLETED']

export default function BookingDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const queryClient = useQueryClient()

  const { data: booking, isLoading } = useQuery(
    ['booking', id],
    () => bookingsAPI.getById(id).then(res => res.data.data),
    { enabled: !!id }
  )

  const cancelMutation = useMutation(
    (reason) => bookingsAPI.cancel(id, reason),
    {
      onSuccess: () => {
        toast.success('Booking cancelled successfully')
        queryClient.invalidateQueries(['booking', id])
      },
      onError: () => {
        toast.error('Failed to cancel booking')
      }
    }
  )

  const handleCancel = () => {
    if (window.confirm('Are you sure you want to cancel this booking?')) {
      cancelMutation.mutate('Customer requested cancellation')
    }
  }

  if (isLoading) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="h-40 bg-gray-200 rounded-xl"></div>
          <div className="h-32 bg-gray-200 rounded-xl"></div>
        </div>
      </div>
    )
  }

  if (!booking) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl font-bold text-gray-900">Booking not found</h2>
        <Link to="/bookings" className="btn-primary mt-4">View All Bookings</Link>
      </div>
    )
  }

  const currentStep = statusSteps.indexOf(booking.bookingStatus)
  const canCancel = ['PENDING', 'ACCEPTED'].includes(booking.bookingStatus)

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Back Button */}
      <button 
        onClick={() => navigate(-1)}
        className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6"
      >
        <ArrowLeftIcon className="h-5 w-5" />
        <span>Back</span>
      </button>

      {/* Header */}
      <div className="flex justify-between items-start mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">{booking.serviceName}</h1>
          <p className="text-gray-600">Booking #{booking.bookingNumber}</p>
        </div>
        <span className={`px-3 py-1 rounded-full text-sm font-medium border ${statusColors[booking.bookingStatus]}`}>
          {booking.bookingStatus?.replace('_', ' ')}
        </span>
      </div>

      {/* Status Progress */}
      {!['CANCELLED', 'REFUNDED', 'DISPUTED'].includes(booking.bookingStatus) && (
        <div className="card p-6 mb-6">
          <div className="flex justify-between items-center">
            {statusSteps.map((step, index) => (
              <div key={step} className="flex flex-col items-center flex-1">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  index <= currentStep ? 'bg-primary-600 text-white' : 'bg-gray-200 text-gray-400'
                }`}>
                  {index < currentStep ? (
                    <CheckCircleIcon className="h-5 w-5" />
                  ) : (
                    <span className="text-sm">{index + 1}</span>
                  )}
                </div>
                <span className={`text-xs mt-2 ${
                  index <= currentStep ? 'text-primary-600 font-medium' : 'text-gray-400'
                }`}>
                  {step.replace('_', ' ')}
                </span>
                {index < statusSteps.length - 1 && (
                  <div className={`hidden sm:block absolute h-0.5 w-full top-4 -z-10 ${
                    index < currentStep ? 'bg-primary-600' : 'bg-gray-200'
                  }`} />
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Booking Details */}
      <div className="card p-6 mb-6">
        <h2 className="font-semibold text-gray-900 mb-4">Booking Details</h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="flex items-start gap-3">
            <CalendarIcon className="h-5 w-5 text-gray-400 mt-0.5" />
            <div>
              <p className="text-sm text-gray-500">Date</p>
              <p className="font-medium">{format(new Date(booking.scheduledDate), 'EEEE, MMMM d, yyyy')}</p>
            </div>
          </div>
          
          <div className="flex items-start gap-3">
            <ClockIcon className="h-5 w-5 text-gray-400 mt-0.5" />
            <div>
              <p className="text-sm text-gray-500">Time</p>
              <p className="font-medium">{booking.scheduledTime}</p>
            </div>
          </div>
          
          <div className="flex items-start gap-3 sm:col-span-2">
            <MapPinIcon className="h-5 w-5 text-gray-400 mt-0.5" />
            <div>
              <p className="text-sm text-gray-500">Service Address</p>
              <p className="font-medium">{booking.serviceAddress}</p>
              <p className="text-sm text-gray-600">{booking.servicePincode}</p>
            </div>
          </div>
        </div>

        {booking.issueDescription && (
          <div className="mt-4 pt-4 border-t">
            <p className="text-sm text-gray-500 mb-1">Issue Description</p>
            <p className="text-gray-700">{booking.issueDescription}</p>
          </div>
        )}
      </div>

      {/* Provider Info */}
      <div className="card p-6 mb-6">
        <h2 className="font-semibold text-gray-900 mb-4">Service Provider</h2>
        
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-primary-100 rounded-full flex items-center justify-center">
            <span className="text-xl font-bold text-primary-600">
              {booking.providerName?.charAt(0)}
            </span>
          </div>
          <div className="flex-1">
            <p className="font-medium text-gray-900">{booking.providerName}</p>
            {booking.businessName && (
              <p className="text-sm text-gray-600">{booking.businessName}</p>
            )}
          </div>
          <a 
            href={`tel:${booking.providerPhone}`}
            className="btn-secondary px-4 py-2"
          >
            <PhoneIcon className="h-5 w-5" />
          </a>
        </div>
      </div>

      {/* Payment Summary */}
      <div className="card p-6 mb-6">
        <h2 className="font-semibold text-gray-900 mb-4">Payment Summary</h2>
        
        <div className="space-y-2">
          <div className="flex justify-between text-gray-600">
            <span>Service Charge</span>
            <span>₹{booking.estimatedAmount}</span>
          </div>
          {booking.materialCost > 0 && (
            <div className="flex justify-between text-gray-600">
              <span>Material Cost</span>
              <span>₹{booking.materialCost}</span>
            </div>
          )}
          {booking.travelCost > 0 && (
            <div className="flex justify-between text-gray-600">
              <span>Travel Cost</span>
              <span>₹{booking.travelCost}</span>
            </div>
          )}
          {booking.discountAmount > 0 && (
            <div className="flex justify-between text-green-600">
              <span>Discount</span>
              <span>-₹{booking.discountAmount}</span>
            </div>
          )}
          {booking.taxAmount > 0 && (
            <div className="flex justify-between text-gray-600">
              <span>Tax (GST)</span>
              <span>₹{booking.taxAmount}</span>
            </div>
          )}
          <div className="flex justify-between font-semibold text-lg pt-2 border-t">
            <span>Total</span>
            <span className="text-primary-600">₹{booking.finalAmount || booking.estimatedAmount}</span>
          </div>
        </div>
      </div>

      {/* Actions */}
      {canCancel && (
        <div className="flex gap-4">
          <button
            onClick={handleCancel}
            disabled={cancelMutation.isLoading}
            className="flex-1 btn bg-red-50 text-red-600 border border-red-200 hover:bg-red-100"
          >
            {cancelMutation.isLoading ? 'Cancelling...' : 'Cancel Booking'}
          </button>
        </div>
      )}

      {booking.bookingStatus === 'COMPLETED' && !booking.userRating && (
        <div className="card p-6 bg-primary-50 border-primary-200">
          <h3 className="font-medium text-gray-900 mb-2">Rate this service</h3>
          <p className="text-gray-600 text-sm mb-4">Share your experience to help others</p>
          <button className="btn-primary">Leave a Review</button>
        </div>
      )}
    </div>
  )
}
