import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useQuery } from 'react-query'
import { bookingsAPI } from '../services/api'
import { format } from 'date-fns'
import { 
  CalendarIcon, 
  ClockIcon, 
  MapPinIcon,
  ChevronRightIcon
} from '@heroicons/react/24/outline'

const statusColors = {
  PENDING: 'bg-yellow-100 text-yellow-800',
  ACCEPTED: 'bg-blue-100 text-blue-800',
  CONFIRMED: 'bg-blue-100 text-blue-800',
  IN_PROGRESS: 'bg-purple-100 text-purple-800',
  COMPLETED: 'bg-green-100 text-green-800',
  CANCELLED: 'bg-red-100 text-red-800',
  DISPUTED: 'bg-orange-100 text-orange-800',
  REFUNDED: 'bg-gray-100 text-gray-800',
}

const tabs = [
  { key: 'all', label: 'All' },
  { key: 'active', label: 'Active' },
  { key: 'completed', label: 'Completed' },
  { key: 'cancelled', label: 'Cancelled' },
]

export default function Bookings() {
  const [activeTab, setActiveTab] = useState('all')
  const [page, setPage] = useState(0)

  const { data, isLoading } = useQuery(
    ['bookings', page],
    () => bookingsAPI.getMyBookings({ page, size: 10 }).then(res => res.data.data),
    { keepPreviousData: true }
  )

  const filteredBookings = data?.content?.filter(booking => {
    if (activeTab === 'all') return true
    if (activeTab === 'active') return ['PENDING', 'ACCEPTED', 'CONFIRMED', 'IN_PROGRESS'].includes(booking.bookingStatus)
    if (activeTab === 'completed') return booking.bookingStatus === 'COMPLETED'
    if (activeTab === 'cancelled') return ['CANCELLED', 'REFUNDED'].includes(booking.bookingStatus)
    return true
  }) || []

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">My Bookings</h1>

      {/* Tabs */}
      <div className="flex space-x-1 bg-gray-100 rounded-lg p-1 mb-6">
        {tabs.map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === tab.key
                ? 'bg-white text-primary-700 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Bookings List */}
      {isLoading ? (
        <div className="space-y-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="card p-4 animate-pulse">
              <div className="h-4 bg-gray-200 rounded w-1/3 mb-3"></div>
              <div className="h-3 bg-gray-200 rounded w-1/2 mb-2"></div>
              <div className="h-3 bg-gray-200 rounded w-2/3"></div>
            </div>
          ))}
        </div>
      ) : filteredBookings.length > 0 ? (
        <div className="space-y-4">
          {filteredBookings.map(booking => (
            <Link
              key={booking.bookingId}
              to={`/bookings/${booking.bookingId}`}
              className="card p-4 block hover:shadow-md transition-shadow"
            >
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h3 className="font-semibold text-gray-900">{booking.serviceName}</h3>
                  <p className="text-sm text-gray-600">{booking.businessName || booking.providerName}</p>
                </div>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusColors[booking.bookingStatus]}`}>
                  {booking.bookingStatus?.replace('_', ' ')}
                </span>
              </div>

              <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                <div className="flex items-center gap-1">
                  <CalendarIcon className="h-4 w-4" />
                  <span>{format(new Date(booking.scheduledDate), 'MMM d, yyyy')}</span>
                </div>
                <div className="flex items-center gap-1">
                  <ClockIcon className="h-4 w-4" />
                  <span>{booking.scheduledTime}</span>
                </div>
                <div className="flex items-center gap-1">
                  <MapPinIcon className="h-4 w-4" />
                  <span className="truncate max-w-[200px]">{booking.servicePincode}</span>
                </div>
              </div>

              <div className="flex justify-between items-center mt-4 pt-3 border-t">
                <p className="font-semibold text-primary-600">
                  ₹{booking.finalAmount || booking.estimatedAmount}
                </p>
                <ChevronRightIcon className="h-5 w-5 text-gray-400" />
              </div>
            </Link>
          ))}
        </div>
      ) : (
        <div className="card p-8 text-center">
          <CalendarIcon className="h-12 w-12 mx-auto text-gray-300 mb-4" />
          <h3 className="font-medium text-gray-900 mb-2">No bookings found</h3>
          <p className="text-gray-600 mb-4">You haven't made any bookings yet</p>
          <Link to="/categories" className="btn-primary">
            Browse Services
          </Link>
        </div>
      )}

      {/* Pagination */}
      {data?.totalPages > 1 && (
        <div className="flex justify-center gap-2 mt-6">
          <button
            onClick={() => setPage(p => Math.max(0, p - 1))}
            disabled={page === 0}
            className="btn-secondary px-4 py-2 disabled:opacity-50"
          >
            Previous
          </button>
          <span className="px-4 py-2 text-gray-600">
            Page {page + 1} of {data.totalPages}
          </span>
          <button
            onClick={() => setPage(p => p + 1)}
            disabled={page >= data.totalPages - 1}
            className="btn-secondary px-4 py-2 disabled:opacity-50"
          >
            Next
          </button>
        </div>
      )}
    </div>
  )
}
