export default function BookingDetails() {
  return <div className="max-w-7xl mx-auto px-4 py-8 pb-24"><h1 className="text-2xl font-bold">Booking Details</h1><p className="text-gray-600 mt-2">Coming Soon</p></div>
}
